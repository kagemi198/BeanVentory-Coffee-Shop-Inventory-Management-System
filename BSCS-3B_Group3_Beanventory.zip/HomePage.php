<?php
include 'localhost.php';

// Fetch inventory statistics
$totalProducts = 0;
$lowStockCount = 0;
$totalCategories = 0;

try {
  // Total products
  $result = $conn->query("SELECT COUNT(*) as count FROM products");
  if ($result) {
    $row = $result->fetch_assoc();
    $totalProducts = $row['count'] ?? 0;
  }

  // Set shared threshold
  $lowThreshold = defined('LOW_STOCK_THRESHOLD') ? LOW_STOCK_THRESHOLD : 5;
  // Count low stock items (quantity <= threshold)
  $result = $conn->query("SELECT COUNT(*) as count FROM products WHERE quantity > 0 AND quantity <= " . $lowThreshold);
  if ($result) {
    $row = $result->fetch_assoc();
    $lowStockCount = $row['count'] ?? 0;
  }

  // Total unique categories
  $result = $conn->query("SELECT COUNT(DISTINCT category) as count FROM products");
  if ($result) {
    $row = $result->fetch_assoc();
    $totalCategories = $row['count'] ?? 0;
  }

  // Count out-of-stock items (quantity <= 0)
  $result = $conn->query("SELECT COUNT(*) as count FROM products WHERE quantity <= 0");
  if ($result) {
    $row = $result->fetch_assoc();
    $outOfStockCount = $row['count'] ?? 0;
  }
} catch (Exception $e) {
  // Silently fail and use defaults
  $totalProducts = 0;
  $lowStockCount = 0;
  $totalCategories = 0;
  $outOfStockCount = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Brews Coffee Shop</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="homepage.css">
</head>
<body>
  <!-- HEADER -->
  <header>
    <div class="Logo"><img src="Coffee_Logo-removebg-preview.png" class="Logo"></div>
    <nav>
      <ul id="main-nav">  
        <li><a href="HomePage.php">Home</a></li>
        <li><a href="Dashboard.php">Dashboard</a></li>
        <li><a href="Inventory_php.php">Inventory</a></li>
        <li><a href="About.php">About Us</a></li>
        <li class="logout-li">
          <button class="logout-button" onclick="location.href='index.php'" title="Logout" aria-label="Logout">
            <img src="logout.png" alt="Logout" class="logout-icon">
            <span class="logout-text">Logout</span>
            <span class="sr-only">Logout</span>
          </button>
        </li>
      </ul>
    </nav>
    <div class="hamburger">
      <button id="hamburger-btn" aria-label="Toggle navigation" aria-expanded="false">☰</button>
    </div>
  </header>
  <!-- HERO (Inventory-Focused) -->
  <section class="hero-hero">
    <div class="hero-inner">
      <div class="hero-text">
        <h1>Manage Your Coffee Inventory with Confidence</h1>
        <p class="hero-sub">Realtime stock, quick restock alerts, and simple product control — so every cup stays available.</p>
      </div>
      <div class="hero-media" aria-hidden="true">
        <img src="https://i.pinimg.com/736x/fb/56/46/fb56461c72acc88db3e59f7fe7dbef6f.jpg" alt="">
      </div>
    </div>
  </section>
  <!-- INVENTORY HIGHLIGHTS CARD -->
  <section class="inventory-highlights">
    <div class="highlight-card">
      <div class="highlight-icon">📦</div>
      <h3>Inventory Management</h3>
      <div class="highlight-stats">
        <div class="stat-item">
          <span class="stat-number"><?php echo $totalProducts; ?></span>
          <span class="stat-label">Products</span>
        </div>
          <div class="stat-item">
          <span class="stat-number"><?php echo $lowStockCount; ?></span>
          <span class="stat-label">Low Stock</span>
        </div>
        <div class="stat-item">
          <span class="stat-number"><?php echo $outOfStockCount; ?></span>
          <span class="stat-label">Out of Stock</span>
        </div>
        <div class="stat-item">
          <span class="stat-number"><?php echo $totalCategories; ?></span>
          <span class="stat-label">Categories</span>
        </div>
      </div>
      <p class="highlight-desc">Keep your inventory in check. Monitor stock levels and manage products efficiently.</p>
      <a href="Inventory_php.php" class="highlight-btn">Access Inventory System</a>
    </div>
  </section>

  <!-- LOW STOCK ALERT SECTION -->
  <section id="low-stock" class="low-stock-section">
    <h2>⚠️ Low Stock Items (≤ <?php echo $lowThreshold; ?>)</h2>
    <div class="low-stock-container">
      <?php
        $lowStockQuery = "SELECT id, name, category, quantity, price FROM products WHERE quantity > 0 AND quantity <= " . $lowThreshold . " ORDER BY quantity ASC LIMIT 6";
        $lowStockResult = $conn->query($lowStockQuery);
        
        if ($lowStockResult && $lowStockResult->num_rows > 0) {
          while ($product = $lowStockResult->fetch_assoc()) {
            $criticalThreshold = floor($lowThreshold / 2);
            $statusClass = $product['quantity'] <= $criticalThreshold ? 'critical' : 'warning';
            echo "
              <div class='low-stock-item {$statusClass}'>
                <h4>{$product['name']}</h4>
                <p class='category'>{$product['category']}</p>
                <div class='stock-info'>
                  <span class='quantity'>Stock: {$product['quantity']} units</span>
                  <span class='price'>₱{$product['price']}/unit</span>
                </div>
              </div>
            ";
          }
        } else {
          echo "<p class='no-low-stock'>All items are well stocked!</p>";
        }
      ?>
    </div>
    <a href="Inventory_php.php" class="view-all-btn">View All Inventory</a>
  </section>

  <!-- OUT OF STOCK ALERT SECTION -->
  <section id="out-of-stock" class="low-stock-section" style="margin-top:1rem">
    <h2>🚫 Out Of Stock Items</h2>
    <div class="low-stock-container">
      <?php
        $outStockQuery = "SELECT id, name, category, quantity, price FROM products WHERE quantity <= 0 ORDER BY name ASC LIMIT 6";
        $outStockResult = $conn->query($outStockQuery);
        if ($outStockResult && $outStockResult->num_rows > 0) {
          while ($o = $outStockResult->fetch_assoc()) {
            echo "
              <div class='low-stock-item out'>
                <h4>{$o['name']}</h4>
                <p class='category'>{$o['category']}</p>
                <div class='stock-info'>
                  <span class='quantity'>Stock: {$o['quantity']} units</span>
                  <span class='price'>₱{$o['price']}/unit</span>
                </div>
                <div style='margin-top:8px'><a href='Inventory_php.php?edit={$o['id']}' class='view-all-btn' style='padding:6px 10px'>Restock</a></div>
              </div>
            ";
          }
        } else {
          echo "<p class='no-low-stock'>No out-of-stock items.</p>";
        }
      ?>
    </div>
    <a href="Inventory_php.php" class="view-all-btn">View All Inventory</a>
  </section>

  <!-- SIGNATURE DRINKS -->
  <section class="drinks-section">
    <h2>Our Signature Drinks</h2>

    <div class="drink-row">
      <div class="drink-image">
        <img src="https://cdn.loveandlemons.com/wp-content/uploads/2023/06/iced-matcha-latte-recipe-580x743.jpg" alt="Iced Matcha Latte">
      </div>
      <div class="drink-text">
        <h3>Iced Matcha Latte</h3>
        <p>A smooth and creamy blend of fine Japanese matcha and milk — earthy, energizing, and refreshing.</p>
      </div>
    </div>

    <div class="drink-row reverse">
      <div class="drink-image">
        <img src="https://i.pinimg.com/736x/f8/56/1e/f8561ea80e14bd1989b4fe87736e1468.jpg" alt="Cappuccino">
      </div>
      <div class="drink-text">
        <h3>Cappuccino</h3>
        <p>Perfectly balanced espresso topped with creamy froth — the ideal morning classic.</p>
      </div>
    </div>

    <div class="drink-row">
      <div class="drink-image">
        <img src="https://lollicupstore.com/cdn/shop/files/MoCafeCaramelFrappe_P7505_12.png?v=1683525311" alt="Caramel Frappe">
      </div>
      <div class="drink-text">
        <h3>Caramel Frappé</h3>
        <p>Cool, creamy, and indulgent — blended espresso with rich caramel drizzle for the perfect treat.</p>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer>
    <p>&copy; 2025 Brews Coffee. All rights reserved.</p>
    <p class="socials">
      <a href="#">Facebook</a> | 
      <a href="#">Instagram</a> | 
      <a href="#">Twitter</a>
    </p>
  </footer>
  <script>
    (function(){
      const btn = document.getElementById('hamburger-btn');
      const nav = document.getElementById('main-nav');
      if (btn && nav) {
        btn.addEventListener('click', function(){
          const isOpen = nav.classList.toggle('open');
          btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
        // Close menu when tapping outside (mobile)
        document.addEventListener('click', function(e){
          if (!nav.classList.contains('open')) return;
          const target = e.target;
          if (!nav.contains(target) && !btn.contains(target)){
            nav.classList.remove('open');
            btn.setAttribute('aria-expanded','false');
          }
        });
      }

      // IntersectionObserver to animate images when they enter viewport
      const images = document.querySelectorAll('.drink-image img');
      if ('IntersectionObserver' in window && images.length){
        const io = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              entry.target.classList.add('in-view');
              // if you want it to animate only once, unobserve after adding
              io.unobserve(entry.target);
            }
          });
        }, { root: null, rootMargin: '0px 0px -8% 0px', threshold: 0.12 });

        // optional: add data-delay on parent rows for a stagger effect
        images.forEach((img, idx) => {
          const parentRow = img.closest('.drink-row');
          if (parentRow) parentRow.setAttribute('data-delay', String((idx % 3) + 1));
          io.observe(img);
        });
      } else {
        // fallback: just add class so images are visible
        images.forEach(img => img.classList.add('in-view'));
      }
    })();
  </script>
</body>
</html>
