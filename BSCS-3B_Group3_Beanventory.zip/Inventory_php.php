<?php
session_start();
include 'localhost.php';
    $id = isset($_GET['edit']) ? intval($_GET['edit']) : null;
    $editData = null;
    $transactionData = null;
    if ($id !== null) {
        $result = $conn->query("SELECT * FROM products WHERE id={$id}");
        if ($result) {
            $editData = $result->fetch_assoc();
        }
        $transactionResult = $conn->query("SELECT * FROM transactions WHERE id={$id}");
        if ($transactionResult) {
            $transactionData = $transactionResult->fetch_assoc();
        }
    }



// Stock status thresholds from config
$lowStockThreshold = defined('LOW_STOCK_THRESHOLD') ? LOW_STOCK_THRESHOLD : 5;
$outOfStockThreshold = 0;

// Get status counts
$statusCountResult = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END) as out_of_stock_count,
    SUM(CASE WHEN quantity > 0 AND quantity <= $lowStockThreshold THEN 1 ELSE 0 END) as low_count
FROM products");
$statusRow = $statusCountResult->fetch_assoc();
$outOfStockCount = intval($statusRow['out_of_stock_count'] ?? 0);
$lowCount = intval($statusRow['low_count'] ?? 0);

// Function to get status badge HTML
function getStatusBadge($quantity, $lowThreshold = null) {
    if ($lowThreshold === null) $lowThreshold = defined('LOW_STOCK_THRESHOLD') ? LOW_STOCK_THRESHOLD : 5;
    if ($quantity <= 0) {
        return "<span class='badge out-of-stock'>Out of Stock</span>";
    } else if ($quantity <= $lowThreshold) {
        return "<span class='badge low'>Low</span>";
    } else {
        return "<span class='badge ok'>OK</span>";
    }
}

// UPDATE PRODUCT
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $category = $conn->real_escape_string($_POST['category']);
    $quantity = floatval($_POST['quantity']);
    $price = floatval($_POST['price']);

    // Fetch old product name so we can update related transactions reliably
    $oldName = null;
    $oldRow = $conn->query("SELECT name FROM products WHERE id={$id}");
    if ($oldRow) {
        $oldRowData = $oldRow->fetch_assoc();
        $oldName = $oldRowData['name'] ?? null;
    }

    $conn->query("UPDATE products SET
        name='{$name}',
        category='{$category}',
        quantity={$quantity},
        price={$price}
        WHERE id={$id}");

    // Update transactions that reference the old product name (if available)
    if ($oldName !== null) {
        $conn->query("UPDATE transactions SET
            ProductName='{$name}',
            Type='{$category}',
            Unit={$quantity},
            Ammount={$price}
            WHERE ProductName='" . $conn->real_escape_string($oldName) . "'");
    }

    // After updating, redirect back to the page
    header('Location: Inventory_php.php');
    exit;
}

// ADD PRODUCT
if (isset($_POST['add'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $category = $conn->real_escape_string($_POST['category']);
    $quantity = floatval($_POST['quantity']);
    $price = floatval($_POST['price']);

    $conn->query("INSERT INTO products (name, category, quantity, price) VALUES ('{$name}','{$category}',{$quantity},{$price})");

    // Also add an initial transaction record to keep transaction history consistent
    $conn->query("INSERT INTO transactions (ProductName, Type, Unit, Ammount) VALUES ('{$name}','{$category}',{$quantity},{$price})");

    header('Location: Inventory_php.php');
    exit;
}

// DELETE PRODUCT
if (isset($_GET['delete'])) {
    $delId = intval($_GET['delete']);
    $r = $conn->query("SELECT * FROM products WHERE id={$delId}");
    if ($r && $r->num_rows > 0) {
        $row = $r->fetch_assoc();
        // Keep recently deleted items in session (most recent first), limit to 10
        if (!isset($_SESSION['recently_deleted']) || !is_array($_SESSION['recently_deleted'])) $_SESSION['recently_deleted'] = [];
        // remove any previous entry with same id
        $_SESSION['recently_deleted'] = array_values(array_filter($_SESSION['recently_deleted'], fn($i) => $i['id'] != $delId));
        array_unshift($_SESSION['recently_deleted'], $row);
        if (count($_SESSION['recently_deleted']) > 10) array_pop($_SESSION['recently_deleted']);
    }
    $conn->query("DELETE FROM products WHERE id={$delId}");
    header('Location: Inventory_php.php');
    exit;
}

// RESTORE DELETED PRODUCT
if (isset($_GET['restore'])) {
    $idx = intval($_GET['restore']);
    if (isset($_SESSION['recently_deleted'][$idx])) {
        $item = $_SESSION['recently_deleted'][$idx];
        $name = $conn->real_escape_string($item['name']);
        $category = $conn->real_escape_string($item['category']);
        $quantity = floatval($item['quantity']);
        $price = floatval($item['price']);

        $conn->query("INSERT INTO products (name, category, quantity, price) VALUES ('{$name}','{$category}',{$quantity},{$price})");
        array_splice($_SESSION['recently_deleted'], $idx, 1);
    }
    header('Location: Inventory_php.php');
    exit;
}

// CLEAR RECENTLY DELETED
if (isset($_GET['clear_deleted'])) {
    $_SESSION['recently_deleted'] = [];
    header('Location: Inventory_php.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Coffee Shop Inventory</title>
        <link href="https://fonts.googleapis.com/icon?family=Material+Symbols+Outlined" rel="stylesheet">
        <link rel="stylesheet" href="./Dashboard_style.css">
        <link rel="stylesheet" href="./inventory_style.css">
</head>
<body>
    <div class="container">
        <aside>
            <div class="top">
                <div class="logo">
                    <img src="Coffee_Logo-removebg-preview.png" alt="logo">
                    <div class="brand">
                        <h2>Coffee Shop</h2>
                        <small class="text-muted">Inventory</small>
                    </div>
                </div>
                <div class="close" id="cls-btn">
                    <input type="checkbox" id="menu-toggle" class="menu-toggle-checkbox">
                    <label for="menu-toggle" class="menu-toggle-label">
                        <span></span>
                        <span></span>
                        <span></span>
                    </label>
                </div>
            </div>
            <div class="sidebar">
                <a href="HomePage.php">
                    <span class="material-symbols-outlined">coffee</span>
                    <h3>COFFEE</h3>
                </a>
                <a href="Dashboard.php">
                    <span class="material-symbols-outlined">grid_view</span>
                    <h3>DASHBOARD</h3>
                </a>
                <a href="Inventory_php.php" class="active">
                    <span class="material-symbols-outlined">list</span>
                    <h3>INVENTORY</h3>
                </a>
                <a href="About.php">
                    <span class="material-symbols-outlined">info</span>
                    <h3>ABOUT</h3>
                </a>
                <a href="index.php">
                    <span class="material-symbols-outlined">logout</span>
                    <h3>Log-Out</h3>
                </a>
            </div>
        </aside>
        <div id="overlay" class="overlay" onclick="hideMenu()"></div>

        <main>
            <h1>Inventory Management</h1>

            <!-- ADD / EDIT FORM -->
            <div class="card">
                <h2><?php echo $editData ? "Edit Ingredient" : "Add Ingredient"; ?></h2>

                <form method="POST">
                    <input type="hidden" name="id" value="<?php echo $editData['id'] ?? ''; ?>">

                    <div class="form-row">
                        <div class="field">
                            <input type="text" name="name" placeholder="Ingredient Name"
                                value="<?php echo $editData['name'] ?? ''; ?>" required>
                        </div>

                        <div class="field">
                            <input type="text" name="category" placeholder="Category"
                                value="<?php echo $editData['category'] ?? ''; ?>" required>
                        </div>

                        <div class="field">
                            <input type="number" step="0.01" name="quantity" placeholder="Quantity (kg)"
                                value="<?php echo $editData['quantity'] ?? ''; ?>" required>
                        </div>

                        <div class="field">
                            <input type="number" step="0.01" name="price" placeholder="Price per kilo"
                                value="<?php echo $editData['price'] ?? ''; ?>" required>
                        </div>

                        <div class="form-actions">
                            <button class="btn" name="<?php echo $editData ? 'update' : 'add'; ?>">
                                <?php echo $editData ? 'Update Product' : 'Add Product'; ?>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- PRODUCT LIST -->
            <div class="card">
                <div class="card-header">
                    <h2>Products List</h2>
                    <div class="badge-row">
                        <?php if ($outOfStockCount > 0): ?>
                            <div class="badge out-of-stock">Out of Stock: <?php echo $outOfStockCount; ?></div>
                        <?php endif; ?>
                        <?php if ($lowCount > 0): ?>
                            <div class="badge low">Low: <?php echo $lowCount; ?></div>
                        <?php endif; ?>
                        <?php if ($outOfStockCount === 0 && $lowCount === 0): ?>
                            <div class="badge ok">All Good</div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="table-responsive">
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Price</th>
                        <th>Total Value</th>
                        <th>Actions</th>
                    </tr>

                    <?php
                    $result = $conn->query("SELECT * FROM products");
                    while ($row = $result->fetch_assoc()) {
                        $total = $row['quantity'] * $row['price'];
                        $statusHtml = getStatusBadge($row['quantity'], $lowStockThreshold);
                        // Determine row class for highlighting
                        $rowClass = '';
                        if ($row['quantity'] <= 0) {
                            $rowClass = 'out-of-stock-row';
                        } else if ($row['quantity'] <= $lowStockThreshold) {
                            $rowClass = 'low-stock-row';
                        }
                        echo "
                        <tr class='{$rowClass}'>
                            <td data-label='Name'>{$row['name']}</td>
                            <td data-label='Category'>{$row['category']}</td>
                            <td data-label='Quantity'>{$row['quantity']}</td>
                            <td data-label='Status'>{$statusHtml}</td>
                            <td data-label='Price'>₱{$row['price']}</td>
                            <td data-label='Total'>₱{$total}</td>
                            <td data-label='Actions'>
                                <div id='actions-{$row['id']}' class='actions-wrapper'>
                                    <a class='btn btn-edit' href='?edit={$row['id']}'>Edit</a>
                                    <a class='btn btn-delete' onclick=\"return confirm('Are you sure you want to delete this product?')\" href='?delete={$row['id']}'>Delete</a>
                                </div>
                            </td>
                        </tr>
                        ";
                    }
                    ?>
                </table>
                </div>
            </div>

            <script>
                // Action buttons are always visible now; no per-row toggle JS required.
                console.log('Actions displayed inline; toggle removed');
            </script>


            <!-- RECENTLY DELETED SECTION -->
            <?php if (!empty($_SESSION['recently_deleted'])): ?>
            <div class="card recently-deleted">
                <div class="card-row">
                    <h3>🗑️ Recently Deleted</h3>
                    <a href="?clear_deleted=1" class="clear-all">Clear All</a>
                </div>
                <div class="deleted-list">
                    <?php foreach ($_SESSION['recently_deleted'] as $idx => $item): ?>
                        <div class="deleted-item">
                            <div>
                                <strong><?php echo $item['name']; ?></strong>
                                <small class="text-muted"><?php echo $item['category']; ?> • <?php echo $item['quantity']; ?>kg</small>
                            </div>
                            <a href="?restore=<?php echo $idx; ?>" class="btn-restore">Restore</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </main>

        <div class="right">
            <div class="top">
                <button id="menu-btn">
                    <span class="material-symbols-outlined">menu</span>
                </button>
                <div class="themeswitch">
                    <span class="material-symbols-outlined active">light_mode</span>
                    <span class="material-symbols-outlined">dark_mode</span>
                </div>
                <div class="profile">
                    <div class="info">
                        <p>Hey, <b>USER</b></p>
                        <small class="text-muted">Admin</small>
                    </div>
                    <div class="profile-photo">
                        <img src="ProfilePic.png" alt="profilephoto">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const sideMenus = document.querySelectorAll("aside, .sidebar");
        const menuBtns = document.querySelectorAll("#menu-btn");
        const closeBtns = document.querySelectorAll("#cls-btn");
        const themeToggler = document.querySelector(".themeswitch");
        const overlay = document.querySelector('#overlay');
        const menuToggle = document.getElementById('menu-toggle');

        // Ensure menu toggle is unchecked on page load
        if (menuToggle) menuToggle.checked = false;

        function showMenu() {
            sideMenus.forEach(sm => sm.classList.add('show'));
            if (overlay) overlay.classList.add('show');
            if (menuToggle) menuToggle.checked = true;
            document.body.classList.add('menu-open');
        }

        function hideMenu() {
            sideMenus.forEach(sm => sm.classList.remove('show'));
            if (overlay) overlay.classList.remove('show');
            if (menuToggle) menuToggle.checked = false;
            document.body.classList.remove('menu-open');
        }

        menuBtns.forEach(btn => btn.addEventListener('click', showMenu));
        closeBtns.forEach(btn => btn.addEventListener('click', hideMenu));
        if (overlay) overlay.addEventListener('click', hideMenu);

        // Allow the checkbox (if present) to toggle the menu
        if (menuToggle) menuToggle.addEventListener('change', () => {
            if (menuToggle.checked) showMenu(); else hideMenu();
        });

        // Close menu when clicking any sidebar link (mobile)
        document.querySelectorAll('aside .sidebar a').forEach(a => a.addEventListener('click', () => { if (window.innerWidth <= 768) hideMenu(); }));

        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) { hideMenu(); }
        });

        // Ensure menu closed on initial load to avoid it remaining open
        window.addEventListener('load', () => { hideMenu(); });

        // Also remove any leftover 'show' classes and immediately hide (in case load fired earlier)
        document.querySelectorAll('.show').forEach(el => el.classList.remove('show'));
        hideMenu();

        // Allow ESC to hide the menu on mobile
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') hideMenu();
        });

        if (themeToggler) themeToggler.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme')
            const spans = themeToggler.querySelectorAll('span');
            spans.forEach(s => s.classList.toggle('active'));
        });
    </script>
</body>
</html>

