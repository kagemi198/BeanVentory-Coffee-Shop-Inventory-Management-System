<?php include "localhost.php"; ?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login</title>
            <link rel="stylesheet" href="AdminLoginForm.css">
                            <!-- Google Font -->
            <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet">

        </head>
        <body>
            <img src="Coffeeshop.jpg" alt="Coffeeshop Image" class="bg-image">
            
            <!-- Title and Slogan Section -->
            <div class="header-section">
                <h1>☕ Brews Coffee Shop</h1>
                <p class="slogan">Your Premium Coffee Inventory Management Portal</p>
            </div>
            
            <div class="loginbox">
                <form class="loginForm" id="loginForm" novalidate>
                    <h2>Admin Login</h2>
                    <div class="inputbox">
                    <p>Username:</p>
                    <input type="text" id="username" name="username" placeholder="Username" required>
                    </div>
                    <div class="inputbox">
                    <p>Password:</p>
                    <input type="password" id="password" name="password" placeholder="Password" required> 
                    </div>
                    <button type="submit">Login</button>
                    <div id="errorMsg" class="error" aria-live="polite">Invalid username or password.</div>
                </form>
            </div>
           <script >
            document.getElementById('loginForm').addEventListener('submit', function(event) {
                event.preventDefault(); // Prevent form submission

                // Clear previous error message
                const errorMsg = document.getElementById('errorMsg');
                errorMsg.style.display = 'none';

                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;

                if(username === 'admin' && password === 'password') {
                    alert('Login successful!');
                    // Redirect to admin dashboard or another page
                    window.location.href = 'HomePage.php';
                } else {
                    errorMsg.style.display = 'block';
                }
            });
           </script>
        </body>
    </html>