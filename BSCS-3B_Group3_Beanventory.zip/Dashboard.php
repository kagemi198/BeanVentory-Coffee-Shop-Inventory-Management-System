<?php 
// Load environment-specific DB config (prefer hosting config, fallback to local)
include 'localhost.php';// Initialize session for delete history
session_start();
if (!isset($_SESSION['deleted_transactions'])) {
    $_SESSION['deleted_transactions'] = [];
}

// DELETE TRANSACTION
if (isset($_GET['delete_trans'])) {
    $trans_id = intval($_GET['delete_trans']);
    $transResult = $conn->query("SELECT * FROM transactions WHERE id=$trans_id");
    if ($transResult && $transResult->num_rows > 0) {
        $transData = $transResult->fetch_assoc();
        // Store deletion (keep last 5)
        $_SESSION['deleted_transactions'] = array_values(array_filter($_SESSION['deleted_transactions'], fn($t) => $t['id'] != $trans_id));
        array_unshift($_SESSION['deleted_transactions'], $transData);
        if (count($_SESSION['deleted_transactions']) > 5) {
            array_pop($_SESSION['deleted_transactions']);
        }
    }
    $conn->query("DELETE FROM transactions WHERE id=$trans_id");
    header('Location: Dashboard.php');
    exit;
}

// RESTORE TRANSACTION
if (isset($_GET['restore_trans'])) {
    $idx = intval($_GET['restore_trans']);
    if (isset($_SESSION['deleted_transactions'][$idx])) {
        $t = $_SESSION['deleted_transactions'][$idx];
        $conn->query("INSERT INTO transactions (ProductName, Type, Unit, Ammount) VALUES ('" . $conn->real_escape_string($t['ProductName']) . "','" . $conn->real_escape_string($t['Type']) . "'," . $t['Unit'] . "," . $t['Ammount'] . ")");
        array_splice($_SESSION['deleted_transactions'], $idx, 1);
        header('Location: Dashboard.php');
        exit;
    }
}

// CLEAR DELETE HISTORY
if (isset($_GET['clear_trans_history'])) {
    $_SESSION['deleted_transactions'] = [];
    header('Location: Dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang=en>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>COFFEE DASHBOARD</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Symbols+Outlined" rel="stylesheet">
  <link rel="stylesheet" href="./Dashboard_style.css">
</head>

<body>
  <div class="container">
    <aside>
      <div class="top">
        <div class="logo">
          <img src="Coffee_Logo-removebg-preview.png" alt="logo">
          <h2>DASH<span class="danger">BOARD</span></h2>
        </div>
        <div class="close" id="cls-btn">
          <input type="checkbox" id="menu-toggle" class="menu-toggle-checkbox">
          <label for="menu-toggle" class="menu-toggle-label">
            <span></span>
            <span></span>
            <span></span>
          </label>
        </div>
      </div>
      <div class="sidebar">
        <a href="HomePage.php">
          <span class="material-symbols-outlined">coffee</span>
          <h3>COFFEE</h3>
        </a>
        <a href="Dashboard.php" class="active">
          <span class="material-symbols-outlined">grid_view</span>
          <h3>DASHBOARD</h3>
        </a>
        <a href="Inventory_php.php">
          <span class="material-symbols-outlined">list</span>
          <h3>INVENTORY</h3>
        </a>
        <a href="About.php">
          <span class="material-symbols-outlined">info</span>
          <h3>ABOUT</h3>
        </a>
        <a href="index.php">
          <span class="material-symbols-outlined">logout</span>
          <h3>Log-Out</h3>
        </a>
      </div>
    </aside>
    <div id="overlay" class="overlay"></div>
    <main>
      <h1>DASHBOARD</h1>
      <div class="user">
        <div class="interval">
          <ul>
            <li>Weekly</li>
            <li class="active">Monthly</li>
          </ul>
        </div>
      </div>
      <div class="insights">
        <!--Credit Sales-->
        <div class="credit">
          <span class="material-symbols-outlined">credit_card_clock</span>
          <div class="middle">
            <div class="left">
              <h3>Credit Score</h3>
              <h1>PHP 34,291</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx='38' cy='38' r='36'></circle>
              </svg>
              <div class="number">
                <p>68%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">Last 24 Hours</small>
        </div>
        <!--Profit Sales-->
        <div class="profit">
          <span class="material-symbols-outlined">money_bag</span>
          <div class="middle">
            <div class="left">
              <h3>Profit Sale</h3>
              <h1>PHP 73,915</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx='38' cy='38' r='36'></circle>
              </svg>
              <div class="number">
                <p>81%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">Last 24 Hours</small>
        </div>
        <!--Channel Sales-->
        <div class="channel">
          <span class="material-symbols-outlined">wifi_channel</span>
          <div class="middle">
            <div class="left">
              <h3>Channel Sales</h3>
              <h1>PHP 52,412</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx='38' cy='38' r='36'></circle>
              </svg>
              <div class="number">
                <p>59%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">Last 24 Hours</small>
        </div>
      </div>
      <!--Transactio Tables-->
      <div class="transaction-history">
        <h2>Transaction History</h2>

        <style>
          .hidden {
            display: none;
          }
        </style>
        <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>ProductName</th>
              <th>Type</th>
              <th>Units</th>
              <th>Ammount</th>
              <th>Total Price</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="product-table">
            <?php
            $result = mysqli_query($conn, "SELECT * FROM transactions");
            $index = 0;
            while ($row = mysqli_fetch_assoc($result)) {
              $index++;
              $hiddenClass = ($index > 5) ? 'class="hidden"' : '';
              $rowId = $row['id'] ?? '';
                        echo "
                        <tr $hiddenClass>
                          <td data-label='ProductName'><span class='cell-value'>{$row['ProductName']}</span></td>
                          <td data-label='Type'><span class='cell-value'>{$row['Type']}</span></td>
                          <td data-label='Units'><span class='cell-value'>{$row['Unit']}</span></td>
                          <td data-label='Ammount'><span class='cell-value'>{$row['Ammount']}</span></td>
                          <td class='primary'><a href='Inventory_php.php'><span class='cell-value'>Details</span></a></td>
                          <td data-label='Action'>
                            <button id='toggle-{$rowId}' tabindex='0' aria-label='Open actions' class='small-action-toggle' aria-expanded='false' aria-controls='actions-{$rowId}' role='button' title='Actions' type='button'>⋮</button>
                            <div id='actions-{$rowId}' class='actions-wrapper'>
                              <a href='?delete_trans={$rowId}' onclick=\"return confirm('Delete this transaction?')\" style='color:#c0392b;cursor:pointer;text-decoration:underline'>Delete</a>
                            </div>
                          </td>
                        </tr>
                      ";
            }
            ?>
          </tbody>
        </table>
        </div>
        <a href="#" id="show-more">Show More</a>
        <script>
          document.getElementById("show-more").addEventListener("click", function(e) {
            e.preventDefault();
            const hiddenRows = document.querySelectorAll("#product-table tr.hidden");
            for (let i = 0; i < 5 && i < hiddenRows.length; i++) {
              hiddenRows[i].classList.remove("hidden");
            }
            if (document.querySelectorAll("#product-table tr.hidden").length === 0) {
              this.style.display = "none";
            }
          });

            // Small-screen action toggles for dashboard transaction rows
            function closeAllTransActionMenus() {
              document.querySelectorAll('.small-action-toggle[aria-expanded="true"]').forEach(btn => {
                const cell = btn.closest('td');
                const wrapper = cell && cell.querySelector('.actions-wrapper');
                // let CSS handle show/hide; only toggle aria-expanded and class
                btn.setAttribute('aria-expanded', 'false');
                btn.classList.remove('expanded');
              });
            }

            // Per-button handlers and a global outside-click handler so toggles work reliably on touch devices
            document.querySelectorAll('.small-action-toggle').forEach(btn => {
                const toggleHandler = function(e) {
                    e.stopPropagation();
                    const expanded = btn.getAttribute('aria-expanded') === 'true';
                    closeAllTransActionMenus();
                    btn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
                    btn.classList.toggle('expanded', !expanded);
                    const targetId = btn.getAttribute('aria-controls');
                    const wrapper = targetId ? document.getElementById(targetId) : btn.nextElementSibling;
                    if (wrapper) wrapper.classList.toggle('show', !expanded);
                };
                // Pointerdown toggles the menu; mark handled so subsequent click doesn't re-toggle
                btn.addEventListener('pointerdown', function(e){ btn._handled = true; console.log('Dashboard toggle pressed', btn.id); btn.focus(); e.preventDefault(); toggleHandler(e); });
                // Clear the handled flag on pointerup so clicks later will work
                btn.addEventListener('pointerup', function(e){ btn._handled = false; });
                // fallback click: ignore if pointerdown already handled the interaction
                btn.addEventListener('click', function(e){ if (btn._handled) { btn._handled = false; e.stopPropagation(); e.preventDefault(); return; } console.log('Dashboard toggle clicked', btn.id); btn.focus(); e.stopPropagation(); e.preventDefault(); toggleHandler(e); });
                // keyboard activation: Enter or Space
                btn.addEventListener('keydown', function(e){ if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleHandler(e); }});
            });
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.actions-wrapper') && !e.target.closest('.small-action-toggle')) {
                    closeAllTransActionMenus();
                }
            });
            document.addEventListener('pointerdown', function(e) {
                if (!e.target.closest('.actions-wrapper') && !e.target.closest('.small-action-toggle')) {
                    closeAllTransActionMenus();
                }
            });
        </script>
      </div>
    </main>
    <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-symbols-outlined">menu</span>
        </button>
        <div class="themeswitch">
          <span class="material-symbols-outlined active">light_mode</span>
          <span class="material-symbols-outlined">dark_mode</span>
        </div>
        <div class="profile">
          <div class="info">
            <p>Hey, <b>USER</b></p>
            <small class="text-muted">Admin</small>
          </div>
          <div class="profile-photo">
            <img src="ProfilePic.png" alt="profilephoto">
          </div>
        </div>
      </div>
      <div class="recentupdate">
        <h2>Supplier Information</h2>
        <div class="updates">
          <div class="update">
            <div class="profile-photo">
              <img src="ProfilePic.png" alt="">
            </div>
            <div class="message">
              <p><b>Premium Beans Co.</b> Stock replenished: Arabica 50kg</p>
              <small class="text-muted">2 Hrs Ago</small>
            </div>
          </div>
          <div class="update">
            <div class="profile-photo">
              <img src="ProfilePic.png" alt="">
            </div>
            <div class="message">
              <p><b>Quality Imports Ltd.</b> New shipment: Robusta 75kg</p>
              <small class="text-muted">6 Hrs Ago</small>
            </div>
          </div>
          <div class="update">
            <div class="profile-photo">
              <img src="ProfilePic.png" alt="">
            </div>
            <div class="message">
              <p><b>Global Suppliers</b> Delivery scheduled for tomorrow</p>
              <small class="text-muted">12 Hrs Ago</small>
            </div>
          </div>
        </div>
      </div>
      <div class="salesanalysis">
        <h2>Inventory Analytics</h2>
        <?php
        // Get inventory stats
        $totalProdResult = $conn->query("SELECT COUNT(*) as total FROM products");
        $totalProdRow = $totalProdResult->fetch_assoc();
        $totalProducts = $totalProdRow['total'] ?? 0;
        
        $lowStockResult = $conn->query("SELECT COUNT(*) as low FROM products WHERE quantity > 0 AND quantity <= " . LOW_STOCK_THRESHOLD);
        $lowStockRow = $lowStockResult->fetch_assoc();
        $lowStockCount = $lowStockRow['low'] ?? 0;

        $outStockResult = $conn->query("SELECT COUNT(*) as out_of_stock FROM products WHERE quantity IS NULL OR quantity = '' OR quantity <= 0");
        $outStockRow = $outStockResult ? $outStockResult->fetch_assoc() : null;
        $outOfStockCount = $outStockRow['out_of_stock'] ?? 0;
        
        // Use COALESCE to ensure 0 when no rows or nulls are present
        $totalValueResult = $conn->query("SELECT COALESCE(SUM(quantity * price), 0) as total_value FROM products");
        $totalValueRow = $totalValueResult ? $totalValueResult->fetch_assoc() : null;
        $totalInventoryValue = number_format($totalValueRow['total_value'] ?? 0, 2);
        ?>
        <div class="item online">
          <div class="icon">
            <span class="material-symbols-outlined">inventory_2</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>TOTAL PRODUCTS</h3>
              <small class="text-muted">All Items</small>
            </div>
            <h5 class="success">+12%</h5>
            <h3><?php echo $totalProducts; ?></h3>
          </div>
        </div>
        <div class="item offline">
          <div class="icon">
            <span class="material-symbols-outlined">warning</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>LOW STOCK</h3>
              <small class="text-muted">Quantity ≤ <?php echo LOW_STOCK_THRESHOLD; ?></small>
            </div>
            <h5 class="warning"><?php echo $lowStockCount > 0 ? '!Alert' : 'OK'; ?></h5>
            <h3><?php echo $lowStockCount; ?></h3>
          </div>
        </div>
        <div class="item customers">
          <div class="icon">
            <span class="material-symbols-outlined">dangerous</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>OUT OF STOCK</h3>
              <small class="text-muted">Quantity = 0</small>
            </div>
            <h5 class="danger"><?php echo $outOfStockCount > 0 ? '✕ Critical' : '✓ OK'; ?></h5>
            <h3><?php echo $outOfStockCount; ?></h3>
          </div>
        </div>
      </div>

      <!-- DELETED TRANSACTIONS HISTORY -->
      <?php if (!empty($_SESSION['deleted_transactions'])): ?>
      <div class="transaction-history" style="margin-top:2rem;background:#fff8f7;border-left:4px solid #c0392b">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
          <h2>🗑️ Deleted Transactions</h2>
          <a href="?clear_trans_history=1" style="font-size:0.8rem;color:#999;text-decoration:underline">Clear All</a>
        </div>
        <div style="display:flex;flex-direction:column;gap:0.8rem">
          <?php foreach ($_SESSION['deleted_transactions'] as $idx => $trans): ?>
            <div style="padding:10px;background:#fff;border:1px solid #e8d4d0;border-radius:6px;display:flex;justify-content:space-between;align-items:center">
              <div style="flex:1">
                <strong><?php echo $trans['ProductName']; ?></strong>
                <small style="color:#999;display:block"><?php echo $trans['Type']; ?> • <?php echo $trans['Unit']; ?> units • ₱<?php echo $trans['Ammount']; ?></small>
              </div>
              <a href="?restore_trans=<?php echo $idx; ?>" style="background:#6F4E37;color:white;padding:6px 12px;border-radius:4px;text-decoration:none;font-size:0.85rem;cursor:pointer;margin-left:1rem">Restore</a>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <script>
    const sideMenus = document.querySelectorAll("aside, .sidebar");
    const menuBtns = document.querySelectorAll("#menu-btn");
    const closeBtns = document.querySelectorAll("#cls-btn");
    const themeToggler = document.querySelector(".themeswitch");
    const overlay = document.querySelector('#overlay');
    const menuToggle = document.getElementById('menu-toggle');

    // Ensure menu toggle is unchecked on page load
    if (menuToggle) menuToggle.checked = false;

    function showMenu() {
      sideMenus.forEach(sm => sm.classList.add('show'));
      if (overlay) overlay.classList.add('show');
      if (menuToggle) menuToggle.checked = true;
      document.body.classList.add('menu-open');
    }
    function hideMenu() {
      sideMenus.forEach(sm => sm.classList.remove('show'));
      if (overlay) overlay.classList.remove('show');
      if (menuToggle) menuToggle.checked = false;
      document.body.classList.remove('menu-open');
    }

    menuBtns.forEach(btn => btn.addEventListener('click', showMenu));
    closeBtns.forEach(btn => btn.addEventListener('click', hideMenu));
    if (overlay) overlay.addEventListener('click', hideMenu);

    // Allow the checkbox (if present) to toggle the menu
    if (menuToggle) menuToggle.addEventListener('change', () => {
      if (menuToggle.checked) showMenu(); else hideMenu();
    });

    // Close menu when clicking any sidebar link (mobile)
    document.querySelectorAll('aside .sidebar a').forEach(a => a.addEventListener('click', () => { if (window.innerWidth <= 768) hideMenu(); }));

    // Hide side menu when resizing to desktop
    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) { hideMenu(); }
    });

    // Ensure menu closed on initial load to avoid it remaining open
    window.addEventListener('load', () => { hideMenu(); });

    // Also remove any leftover 'show' classes and immediately hide (in case load fired earlier)
    document.querySelectorAll('.show').forEach(el => el.classList.remove('show'));
    hideMenu();

    // Allow ESC to hide the menu on mobile
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') hideMenu();
    });

    if (themeToggler) themeToggler.addEventListener('click', () => {
      document.body.classList.toggle('dark-theme')
      const spans = themeToggler.querySelectorAll('span');
      spans.forEach(s => s.classList.toggle('active'));
    });
  </script>
</body>

</html>