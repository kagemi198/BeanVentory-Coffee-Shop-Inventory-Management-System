<?php
$servername = "sql308.infinityfree.com";  // MySQL Hostname
$username = "if0_40588634";       //MySQL Username
$password = "Yashiro198";       //MySQL Password
$database = "if0_40588634_db_inventory_system"; //database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Ensure app-wide constants are available on this environment
if (!defined('LOW_STOCK_THRESHOLD')) {
    define('LOW_STOCK_THRESHOLD', 5);
}
?>
