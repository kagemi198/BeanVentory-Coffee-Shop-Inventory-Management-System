<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db   = "inventory";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Global threshold for low stock across the app
if (!defined('LOW_STOCK_THRESHOLD')) {
    define('LOW_STOCK_THRESHOLD', 5);
}

?>