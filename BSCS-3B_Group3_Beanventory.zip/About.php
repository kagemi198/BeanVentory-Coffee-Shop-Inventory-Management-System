<?php include "localhost.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee Shop Staff</title>
  <link rel="stylesheet" href="About.css">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Navigation -->
  <nav>
    <div class="nav-inner">
      <ul id="main-nav-about">
        <li><a href="HomePage.php"><span class="link-text">Home</span></a></li>
        <li><a href="Dashboard.php"><span class="link-text">Dashboard</span></a></li>
        <li><a href="Inventory_php.php"><span class="link-text">Inventory</span></a></li>
        <li><a href="About.php"><span class="link-text">About Us</span></a></li>
        <li class="logout-li">
          <button class="logout-button" onclick="location.href='index.php'" title="Logout" aria-label="Logout">
            <img src="logout.png" alt="Logout" class="logout-icon">
            <span class="logout-text">Logout</span>
          </button>
        </li>
      </ul>
      <div class="hamburger">
        <button id="hamburger-btn-about" aria-label="Toggle navigation" aria-expanded="false">☰</button>
      </div>
    </div>
  </nav>

  <!-- Staff Section -->
  <section class="staff-section">
    <h2 class="section-title">Mission & Vision</h2>
    
    <div class="mission-vision-container">
      <div class="mission-box">
        <h3>Our Mission</h3>
        <p>To deliver exceptional coffee experiences by maintaining the highest quality standards, fostering a welcoming atmosphere, and empowering our team to provide outstanding service to every customer.</p>
      </div>
      <div class="vision-box">
        <h3>Our Vision</h3>
        <p>To be the premier coffee destination, known for our premium coffee selection, innovative beverages, and commitment to sustainability and community engagement.</p>
      </div>
    </div>

  <!-- Our Team Section -->
  <section class="staff-section">
    <h2 class="section-title">Our Team</h2>

    <div class="staff-container">

      <div class="staff-card">
        <div class="card-inner">
          <div class="card-front">
            <img src="Jacob.jpg" alt="Barista 1">
            <h3>Jacob Cabrera</h3>
            <p>Barista</p>
          </div>
          <div class="card-back">
            <h3>Jacob Cabrera</h3>
            <p>Jacob is a skilled barista known for his creative latte art and exceptional coffee brewing skills.</p>
            <button>Learn More</button>
          </div>
        </div>
      </div>

      <div class="staff-card">
        <div class="card-inner">
          <div class="card-front">
            <img src="Eduard.jpg" alt="Barista 2">
            <h3>Eduard Lamigo</h3>
            <p>Barista</p>
          </div>
          <div class="card-back">
            <h3>Eduard Lamigo</h3>
            <p>Eduard ensures quality coffee preparation and delivers excellent customer service daily.</p>
            <button>Learn More</button>
          </div>
        </div>
      </div>

      <div class="staff-card">
        <div class="card-inner">
          <div class="card-front">
            <img src="Justine.jpg" alt="Service Crew">
            <h3>Justine Manaloto</h3>
            <p>Service Crew</p>
          </div>
          <div class="card-back">
            <h3>Justine Manaloto</h3>
            <p>Justine provides friendly and efficient service, making every customer feel welcome.</p>
            <button>Learn More</button>
          </div>
        </div>
      </div>

      <div class="staff-card">
        <div class="card-inner">
          <div class="card-front">
            <img src="Carmella.jpeg" alt="Cashier">
            <h3>Carmela Vergara</h3>
            <p>Cashier</p>
          </div>
          <div class="card-back">
            <h3>Carmela Vergara</h3>
            <p>Carmela handles all transactions with a smile and ensures smooth daily operations.</p>
            <button>Learn More</button>
          </div>
        </div>
      </div>

      <div class="staff-card">
        <div class="card-inner">
          <div class="card-front">
            <img src="Aldrin.jpeg" alt="Assistant Manager">
            <h3>Aldrin Fabian</h3>
            <p>Assistant Manager</p>
          </div>
          <div class="card-back">
            <h3>Aldrin Fabian</h3>
            <p>Aldrin manages staff scheduling and maintains top-notch quality standards for the shop.</p>
            <button>Learn More</button>
          </div>
        </div>
      </div>

      <div class="staff-card">
        <div class="card-inner">
          <div class="card-front">
            <img src="Jerome.png" alt="Store Manager">
            <h3>Jerome Capulong</h3>
            <p>Store Manager</p>
          </div>
          <div class="card-back">
            <h3>Jerome Capulong</h3>
            <p>Jerome leads the team with passion, ensuring an exceptional coffee experience for everyone.</p>
            <button>Learn More</button>
          </div>
        </div>
      </div>

    </div>
  </section>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 Brews Coffee. All rights reserved.</p>
    <p class="socials">
      <a href="#">Facebook</a> | 
      <a href="#">Instagram</a> | 
      <a href="#">Twitter</a>
    </p>
  </footer>
  <script>
    (function(){
      const btn = document.getElementById('hamburger-btn-about');
      const nav = document.getElementById('main-nav-about');
      if (!btn || !nav) return;
      btn.addEventListener('click', function(e){
        const isOpen = nav.classList.toggle('open');
        btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
      document.addEventListener('click', function(e){
        if (!nav.classList.contains('open')) return;
        const target = e.target;
        if (!nav.contains(target) && !btn.contains(target)){
          nav.classList.remove('open');
          btn.setAttribute('aria-expanded','false');
        }
      });
    })();
  </script>
</body>
</html>
